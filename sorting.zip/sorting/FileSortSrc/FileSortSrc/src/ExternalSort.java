import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Scanner;


public class ExternalSort
{
    static int N = 0; // size of the file in disk
    static int M = 0; // max items the memory buffer can hold

    public static String externalSort(String fileName)
    {
	String tfile = "anuj-file-";
	Runtime runtime = Runtime.getRuntime();

	LineNumberReader lineReader = null;
	try {
	    lineReader = new LineNumberReader(new FileReader(fileName));
	    while ((lineReader.readLine()) != null);
	    N=lineReader.getLineNumber();

	    
	    M = (int) Math.ceil((double) N/5);
	} catch (Exception ex) {

	} finally { 
	    if(lineReader != null) {
		try
		{
		    lineReader.close();
		}
		catch (IOException e)
		{

		    e.printStackTrace();
		}
	    }
	}


	String[] buffer = new String[M < N ? M : N];
	//HashMap<String, Integer> myMap = new HashMap<String, Integer>();
	try
	{
	    FileReader fr = new FileReader(fileName);

	    BufferedReader br = new BufferedReader(fr);

	    int slices = (int) Math.ceil((double) N/M);



	    int i, j;
	    i = j = 0;
	    // Iterate through the elements in the file
	    for (i = 0; i < slices; i++)
	    {
		// Read M-element chunk at a time from the file
		for (j = 0; j < (M < N ? M : N); j++)
		{
		    String t = br.readLine();
		    if (t != null && !t.equalsIgnoreCase(""))
			buffer[j] = t;
		    else {
			buffer[j] ="z#$%";
			/*break;*/
		    }


		}

		// Sort M elements

		Arrays.sort(buffer);
		// Write the sorted numbers to temp file
		FileWriter fw = new FileWriter("C:\\temp\\"+tfile + Integer.toString(i) + ".txt");
		PrintWriter pw = new PrintWriter(fw);
		for (int k = 0; k < j; k++) {
		    if(!"z#$%".equalsIgnoreCase(buffer[k]))
			pw.println(buffer[k]);
		}

		pw.close();
		fw.close();

	    }

	    buffer=null;

	    br.close();
	    fr.close();

	    // Now open each file and merge them, then write back to disk
	    String[] topNums = new String[slices];
	    BufferedReader[] brs = new BufferedReader[slices];

	    for (i = 0; i < slices; i++)
	    {
		brs[i] = new BufferedReader(new FileReader("C:\\temp\\"+tfile + Integer.toString(i) + ".txt"));
		String t = brs[i].readLine();
		if (t != null && !t.equalsIgnoreCase("")) {
		    topNums[i] = t;

		}		
		else
		    topNums[i] = null;
	    }

	    FileWriter fw = new FileWriter("external-sorted.txt");

	    PrintWriter pw = new PrintWriter(fw);

	    //Set<String> keySet = myMap.keySet();
	    List myList = new ArrayList<String>(Arrays.asList(topNums));
	    Collections.sort(myList);

	    /*int index=0;

	    while(index<myList.size()) {
		if(null!=myList.get(index) &&!myList.get(index).equals("")) {
		    pw.println(myList.get(0));
		    break;
		} 

		index++;
	    }*/
	    boolean end =false;
	    while (!end)
	    {

		//find out minimum of topnum and write it into the file

		int index=0;
		int removed=0;
		while(index<myList.size()) {
		    if(null!=myList.get(index) &&!myList.get(index).equals("")) {
			removed = getTopIndex((String)myList.get(index),topNums);
			pw.println(myList.get(index));
			break;
		    } 

		    index++;
		}
		String next = brs[removed].readLine();

		if(next!=null && next.length()>0) {

		    topNums[removed] = next;
		}
		else {
		    topNums[removed]="";
		}

		myList = new ArrayList<String>(Arrays.asList(topNums));
		Collections.sort(myList);
		end = isArrayEmpty(topNums);

	    }

	    topNums=null;
	    myList = null;

	    /*maxMemory = runtime.maxMemory();
	    allocatedMemory = runtime.totalMemory();
	    freeMemory = runtime.freeMemory();
	     */

	    for (i = 0; i < slices; i++) {
		brs[i].close();
		File file = new File("C:\\temp\\"+tfile + Integer.toString(i) + ".txt");
		System.out.println(file.delete());

	    }
	    pw.close();
	    fw.close();
	    return "success";
	    /*  System.out.println("free memory: " + format.format(freeMemory / 1024));
	    System.out.println("allocated memory: " + format.format(allocatedMemory / 1024));
	    System.out.println("max memory: " + format.format(maxMemory / 1024));
	    System.out.println("total free memory: " + format.format((freeMemory + (maxMemory - allocatedMemory)) / 1024) );*/
	}
	catch (FileNotFoundException e)
	{
	    System.out.println("File not Found please enter again:- ");
	    return "fail";  
	    //main(buffer);

	} catch (IOException e) {
	    e.printStackTrace();
	    return "fail"; 
	}
	
    }



   /* public static void main(String[] args)
    {
	//String fileName = generateInput(N);
	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	Date date = new Date();
	System.out.println(dateFormat.format(date));
	Scanner in = new Scanner(System.in);

	System.out.println("Enter the file name:- ");
	String fileName = in.nextLine();
	InputFrame sortFrame = new InputFrame("FILE SORTING");
	
	
	//externalSort(fileName);

	dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	date = new Date();
	System.out.println(dateFormat.format(date));
    }*/

    public static int getTopIndex(String element,String [] array) {

	for(int i=0;i<array.length;i++) {
	    if(null!=element && !"".equalsIgnoreCase(element) && element.equals(array[i])) {
		return i;
	    }
	}


	return 0;
    }

    public static boolean isArrayEmpty(String [] array) {
	int count=0;
	for(int i=0;i<array.length;i++) {
	    if(null==array[i] || "".equals(array[i])) {
		count++;
	    }
	}


	if(count==array.length) {
	    return true;
	}
	else {
	    return false;
	}
    }
}


