import java.awt.FlowLayout;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;


public class InputFrame extends JFrame
{
    JButton jButton = null;
    JButton sortButton = null;
    JTextField jTextField =null;
    String fileName ="error";
    JLabel waitLabel =null;
    public InputFrame(String title)
    {
	super(title);

	this.setVisible(true);
	this.setSize(600, 200);
	this.setResizable(false);
	this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	this.setLocation(getLocationOnScreen());
	this.setLayout(new FlowLayout());
	jButton = new JButton("Choose File");
	sortButton = new JButton("Sort");
	jTextField = new JTextField("no file chosen!!");
	waitLabel = new JLabel("Processing....Please Wait....");

	jTextField.setEditable(false);
	this.add(jTextField);
	this.add(jButton);
	this.add(sortButton);
	this.add(waitLabel);
	waitLabel.hide();
	sortButton.addMouseListener(new java.awt.event.MouseAdapter() {
	    public void mouseClicked(java.awt.event.MouseEvent e) {
		if (null==fileName || fileName.equalsIgnoreCase(""))
		{
		    JOptionPane.showMessageDialog(null, "No File Selected");

		}
		else {
		    waitLabel.show();
		    
		    JOptionPane.showMessageDialog(null, "Processing....Please Wait....");
		    waitLabel.setText("Processing....Please Wait....");
		    String result = new ExternalSort().externalSort(fileName);
		    if(null!=result && result.equalsIgnoreCase("success")) {
			waitLabel.setText("Done...Sorted File Name:-  external-sorted.txt");
		    }
		    else {
			JOptionPane.showMessageDialog(null, "Wrong File Selected..Try Again");
		    }
		}
	    }
	});
	jButton.addMouseListener(new java.awt.event.MouseAdapter() {
	    public void mouseClicked(java.awt.event.MouseEvent e) {
		if (jButton.isEnabled())
		{
		    JFileChooser chooser = new JFileChooser();
		    chooser.setCurrentDirectory(new File("."));
		    chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		    chooser.showOpenDialog(null);
		    File selectedPfile = chooser.getSelectedFile();

		    if(null!=selectedPfile) {
			jTextField.setText(selectedPfile.getAbsolutePath());
			fileName = selectedPfile.getAbsolutePath();
		    }
		    else {
			jTextField.setText("no file selected!!");
			fileName="";
		    }

		}
	    }
	});

    }


    public static void main(String[] args)
    {
	SwingUtilities.invokeLater(new Runnable(){ public void run(){

	    new InputFrame("FILE SORTING");

	}});

    }


}
